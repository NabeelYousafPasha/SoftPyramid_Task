<table class="table table-striped table-bordered table-hover dataTables-example" >
    <thead>
    <tr>
        <th>{{ trans('lang.serial_num') }}</th>
        <th>{{ trans('lang.transaction.transaction_detail') }}</th>
        <th>{{ trans('lang.transaction.transaction_sales_date') }}</th>
        <th>{{ trans('lang.transaction.transaction_sales_price') }}</th>
        <th>{{ trans('lang.payments.page_title') }}</th>
        <th>{{ trans('lang.actions.created_at') }}</th>
        <th>{{ trans('lang.actions.actions') }}</th>
    </tr>
    </thead>
    <tbody>
    @isset($transactions)
        @forelse($transactions as $key => $transaction)
            <tr>
                <td>{{ ++$key }}</td>
                <td>{{ $transaction->transaction_detail }}</td>
                <td>{{ $transaction->transaction_sales_date }}</td>
                <td>{{ $transaction->transaction_sales_price }}</td>
                <td></td>
                <td>{{ $transaction->created_at }}</td>
                <td>
                    <div class="btn-group btn-group-xs">
                        <a
                            href="#"
                            title="{{ trans('lang.actions.edit') }} {{ trans('lang.transaction.entity') }}"
                            class="btn btn-primary btn-sm"
                            data-href="/transactions/{{ $transaction->id }}/edit"
                            data-toggle="modal"
                            data-target="#softpyramid_modal"
                        >
                            <i class="fa fa-pencil fa-fw"></i>
                        </a>
                    </div>
                </td>
            </tr>
        @empty
        @endforelse
    @endisset
    </tbody>
</table>
