<div class="footer">
    <div class="pull-right">
        By: <strong> nabeelyousafpasha@gmail.com </strong>
    </div>
    <div>
        <strong>Copyright</strong> {{ config('app.name', 'Laravel') }} &copy; {{ date('Y') }}
    </div>
</div>
