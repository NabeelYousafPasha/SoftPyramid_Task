<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
    <h4 class="modal-title"><?php echo trans('lang.actions.edit').' '.trans('lang.transaction.entity'); ?></h4>
</div>
<div class="modal-body">
    <form
        id="editTransactionForm"
        name="editTransactionForm"
    >
        <?php echo method_field('PATCH'); ?>
        <?php echo $__env->make('dashboard.transaction.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary" id="editTransactionButton"><?php echo e(trans('lang.actions.save')); ?></button>
</div>
<?php /**PATH C:\xampp\htdocs\SoftPyramidTask\resources\views/dashboard/transaction/edit.blade.php ENDPATH**/ ?>