<table class="table table-striped table-bordered table-hover dataTables-example" >
    <thead>
    <tr>
        <th><?php echo e(trans('lang.serial_num')); ?></th>
        <th><?php echo e(trans('lang.transaction.transaction_detail')); ?></th>
        <th><?php echo e(trans('lang.transaction.transaction_sales_date')); ?></th>
        <th><?php echo e(trans('lang.transaction.transaction_sales_price')); ?></th>
        <th><?php echo e(trans('lang.payments.page_title')); ?></th>
        <th><?php echo e(trans('lang.actions.created_at')); ?></th>
        <th><?php echo e(trans('lang.actions.actions')); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php if(isset($transactions)): ?>
        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($transaction->transaction_detail); ?></td>
                <td><?php echo e($transaction->transaction_sales_date); ?></td>
                <td><?php echo e($transaction->transaction_sales_price); ?></td>
                <td></td>
                <td><?php echo e($transaction->created_at); ?></td>
                <td>
                    <div class="btn-group btn-group-xs">
                        <a
                            href="#"
                            title="<?php echo e(trans('lang.actions.edit')); ?> <?php echo e(trans('lang.transaction.entity')); ?>"
                            class="btn btn-primary btn-sm"
                            data-href="/transactions/<?php echo e($transaction->id); ?>/edit"
                            data-toggle="modal"
                            data-target="#softpyramid_modal"
                        >
                            <i class="fa fa-pencil fa-fw"></i>
                        </a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\SoftPyramidTask\resources\views/dashboard/transaction/list.blade.php ENDPATH**/ ?>