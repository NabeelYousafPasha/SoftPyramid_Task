<div class="footer">
    <div class="pull-right">
        By: <strong> nabeelyousafpasha@gmail.com </strong>
    </div>
    <div>
        <strong>Copyright</strong> <?php echo e(config('app.name', 'Laravel')); ?> &copy; <?php echo e(date('Y')); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SoftPyramidTask\resources\views/dashboard/partials/credits.blade.php ENDPATH**/ ?>