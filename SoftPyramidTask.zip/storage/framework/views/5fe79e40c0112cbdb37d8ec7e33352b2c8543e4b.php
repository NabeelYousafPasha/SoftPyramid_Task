<!DOCTYPE html>
<html>
<!-- --------------------------    header stylesheets   -------------------------------- -->
<head>
	<?php echo $__env->make('dashboard.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('stylesheets'); ?>
</head>

<body>
    <div id="wrapper">
<!-- ----------------------------------    sidebar    ----------------------------------- -->
    	<?php echo $__env->make('dashboard.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    	<div id="page-wrapper" class="gray-bg dashbard-1">
<!-- ----------------------------------     navbar    ----------------------------------- -->
    	   <?php echo $__env->make('dashboard.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           <?php if(Session::has('message')): ?>
                <div class="alert alert-info alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <div class="note note-info">
                        <p><?php echo e(Session::get('message')); ?></p>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($errors->count() > 0): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <div class="note note-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
                    
    	   <?php echo $__env->yieldContent('content'); ?>

           <?php echo $__env->make('dashboard.partials.credits', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	</div>
    </div>


    <div class="modal inmodal" id="softpyramid_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content animated flipInY">

            </div>
        </div>
    </div>

<!-- ---------------------------       footer scripts      ---------------------------- -->
	<?php echo $__env->make('dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('scripts'); ?>

    <script>
        $("#softpyramid_modal").on("show.bs.modal", function(t) {
            var e = $(t.relatedTarget);
            e.attr("data-href") && $.get(e.attr("data-href"), function(t) {
                $("#softpyramid_modal").find(".modal-content").html(t);
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SoftPyramidTask\resources\views/dashboard/layout/app.blade.php ENDPATH**/ ?>